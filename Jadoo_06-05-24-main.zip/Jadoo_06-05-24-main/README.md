# Jadoo_06-05-24
Learn step-by-step how to create a stunning and responsive travel website from scratch using HTML, CSS, and JavaScript.
